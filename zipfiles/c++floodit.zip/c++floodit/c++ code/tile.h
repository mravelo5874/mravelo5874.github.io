#pragma once
#include "common.h"


class Tile
{
public:
	Tile();
	void set_position(int x, int y);
	void clear_tile();
	void reset_click();
	void render_tile(SDL_Renderer* game_renderer, int color);
	void handle_event(SDL_Event* tile_event);
	bool been_clicked();

private:
	SDL_Point position;
	int w;
	int h;
	bool inside_tile;
	bool tile_clicked;
};
