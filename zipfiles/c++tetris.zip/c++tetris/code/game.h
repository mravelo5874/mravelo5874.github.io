#pragma once
#include "common.h"
#include "blocks.h"
#include "time.h"

struct RGB_color
{
	int red;
	int green;
	int blue;
};

class Game
{
public:
	Game();
	~Game();
	void check_for_line(int y);
	void delete_line(int y);
	void move_everything_down(int y);
	bool check_game_over();
	void make_blocks_permanent();
	void print();
	void handle_event(SDL_Event* g_event);
	bool colide_with_block();
	void run_game();

private:
	std::vector<std::vector<int>> movement_grid;
	std::vector<std::vector<int>> stacking_grid;
	std::vector<std::vector<RGB_color>> color_grid;
	Blocks next_block;
	Blocks current_block;
	Time game_timer;
};
