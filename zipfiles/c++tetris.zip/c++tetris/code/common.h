#ifndef _COMMON_H_
#define _COMMON_H_

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <string>
#include <sstream>
#include <cstdlib>
#include <time.h>
#include <vector>

#define MAX 128

const static int SCREEN_WIDTH = 480;
const static int SCREEN_HEIGHT = 720;
const static int BLOCK_SIZE = 24;
const static int GAME_COLUMNS = 10;
const static int GAME_ROWS = 20;

extern SDL_Window* game_window;
extern SDL_Renderer* game_renderer;
extern TTF_Font* game_font;

static void clear_grid(std::vector<std::vector<int>> &grid)
{
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			grid[i][j] = 0;
		}
	}
}

static void print_grid(std::vector<std::vector<int>> &grid)
{
	system("CLS");
	for (int y = 1; y < GAME_ROWS + 1; y++)
	{
		printf("|");
		for (int x = 1; x < GAME_COLUMNS + 1; x++)
		{
			if (grid[x][y] == 0)
			{
				printf("--");
			}
			else if (grid[x][y] == 1)
			{
				printf("[]");
			}
		}
		printf("|\n");
	}
	printf("\n");
}
#endif
