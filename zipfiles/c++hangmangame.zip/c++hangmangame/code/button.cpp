#include "button.h"
#include "common.h"

Button_t::Button_t()
{
	position.x = 0;
	position.y = 0;
	sprites[0] = NULL;
	sprites[1] = NULL;
	current_sprite = NULL;
	pushed = false;
	width_height.x = 0;
	width_height.y = 0;
}

void Button_t::set_position(int x, int y)
{
	position.x = x;
	position.y = y;
}

void Button_t::handle_event(SDL_Event* button_event)
{
	current_sprite = sprites[0];
	if (button_event->type == SDL_MOUSEMOTION || button_event->type == SDL_MOUSEBUTTONDOWN)
	{
		int x, y;
		SDL_GetMouseState(&x, &y);
		bool inside = true;
		if (x < position.x)
			inside = false;
		else if (x > position.x + width_height.x)
			inside = false;
		else if (y < position.y)
			inside = false;
		else if (y > position.y + width_height.y)
			inside = false;

		if (!inside)
			current_sprite = sprites[0];
		else
		{
			current_sprite = sprites[1];
			if (button_event->type == SDL_MOUSEBUTTONDOWN)
				pushed = true;
		}
	}
}

void Button_t::render()
{
	button_texture->render_texture(position.x, position.y, current_sprite);
}

bool Button_t::been_pressed()
{
	return pushed;
}

void Button_t::reset_button()
{
	pushed = false;
}

void Button_t::set_texture(Texture_t* t)
{
	if (&t != NULL)
		button_texture = t;
}

void Button_t::set_sprite(SDL_Rect* s, int i)
{
	if (&s != NULL)
		sprites[i] = s;
}

void Button_t::set_button_width_height(int w, int h)
{
	width_height.x = w;
	width_height.y = h;
}