#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <stdio.h>
#include <string>
#include <sstream>

#include "texture.h"
#include "button.h"

extern const int SCREEN_WIDTH;
extern const int SCREEN_HEIGHT;

extern const int BUTTON_WIDTH;
extern const int BUTTON_HEIGHT;
extern const int TOTAL_BUTTONS;

extern SDL_Window* game_window;
extern SDL_Renderer* game_renderer;
extern TTF_Font* game_font;

