#include "common.h"
#include "tile.h"
#include "texture.h"
#include "button.h"
#define MAX 512

int SCREEN_WIDTH = 560;
int SCREEN_HEIGHT = 560;
int TILE_WIDTH = 24;

int ROWS = 8;
int NUM_COLORS = 4;

SDL_Window* game_window = NULL;
SDL_Renderer* game_renderer = NULL;
TTF_Font* game_font = NULL;

Texture_t FLOOD_IT_TEXTURE;
Texture_t TURNS_LEFT_TEXURE;
Texture_t ROWS_TEXTURE;
Texture_t COLORS_TEXTURE;
Texture_t ROWS_TEXT;
Texture_t COLORS_TEXT;
Texture_t WIN_TEXT;
Texture_t LOSE_TEXT;
SDL_Color text_color = { 255, 255, 255, 255 };

Texture_t ARROW_TEXTURE;
SDL_Rect arrow_sprites[2];
Button_t arrow_button[4];

Texture_t RESET_TEXTURE;
SDL_Rect reset_sprites[2];
Button_t reset_button;

struct tile_t 
{
	Tile tile;
	int color;
	int x;
	int y;
};

tile_t grid[MAX];

bool initialize();
bool load_media();
void close();

bool initialize()
{
	bool success = true;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize. SDL ERROR: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
			printf("Warning: Linear texture filtering not enabled!");
	}
	game_window = SDL_CreateWindow("Floodit!", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	if (game_window == NULL)
	{
		printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		game_renderer = SDL_CreateRenderer(game_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
		if (game_renderer == NULL)
		{
			printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
			int imgFlags = IMG_INIT_PNG;
			if (!(IMG_Init(imgFlags) & imgFlags))
			{
				printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
				success = false;
			}
			if (TTF_Init() == -1)
			{
				printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
				success = false;
			}
		}
	}
	return success;
}

bool load_media()
{
	bool success = true;

	game_font = TTF_OpenFont("atari_font.ttf", 28);
	if (game_font == NULL)
	{
		printf("Failed to atari_font.ttf. SDL_ttf Error: %s\n", TTF_GetError());
		success = false;
	}
	else
	{
		if (!FLOOD_IT_TEXTURE.load_from_rendered_text("FLOODIT!", text_color))
		{
			printf("Unable to render title texture.\n");
			success = false;
		}
		if (!ROWS_TEXT.load_from_rendered_text("SIZE", text_color))
		{
			printf("Unable to render rows text texture.\n");
			success = false;
		}
		if (!COLORS_TEXT.load_from_rendered_text("COLORS", text_color))
		{
			printf("Unable to render colors text texture.\n");
			success = false;
		}
		if (!WIN_TEXT.load_from_rendered_text("YOU WIN!", text_color))
		{
			printf("Unable to render win text texture.\n");
			success = false;
		}
		if (!LOSE_TEXT.load_from_rendered_text("YOU LOST!", text_color))
		{
			printf("Uable to render lose text texture.\n");
			success = false;
		}
	}

	if (!ARROW_TEXTURE.load_from_file("dot_pngs/arrow_button_sprites.png"))
	{
		printf("Failed to load arrow button texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < 2; i++)
		{
			arrow_sprites[i].x = 0;
			arrow_sprites[i].y = i * 36;
			arrow_sprites[i].w = 48;
			arrow_sprites[i].h = 36;
		}
		for (int x = 0; x < 4; x++)
		{
			arrow_button[x].set_texture(&ARROW_TEXTURE);
			arrow_button[x].set_sprite(&arrow_sprites[0], 0);
			arrow_button[x].set_sprite(&arrow_sprites[1], 1);
			arrow_button[x].set_button_width_height(48, 36);
		}
	}
	
	if (!RESET_TEXTURE.load_from_file("dot_pngs/reset_button_sprites.png"))
	{
		printf("Failed to load reset button texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < 2; i++)
		{
			reset_sprites[i].x = 0;
			reset_sprites[i].y = i * 48;
			reset_sprites[i].w = 48;
			reset_sprites[i].h = 48;
		}
		reset_button.set_texture(&RESET_TEXTURE);
		reset_button.set_sprite(&reset_sprites[0], 0);
		reset_button.set_sprite(&reset_sprites[1], 1);
		reset_button.set_button_width_height(48, 48);
	}

	return success;
}

void close()
{
	FLOOD_IT_TEXTURE.free();
	TURNS_LEFT_TEXURE.free();
	ARROW_TEXTURE.free();
	ROWS_TEXTURE.free();
	COLORS_TEXTURE.free();
	RESET_TEXTURE.free();
	WIN_TEXT.free();
	LOSE_TEXT.free();

	TTF_CloseFont(game_font);
	game_font = NULL;

	SDL_DestroyRenderer(game_renderer);
	game_renderer = NULL;

	SDL_DestroyWindow(game_window);
	game_window = NULL;

	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

void make_grid()
{
	int start_pos = ((SCREEN_WIDTH - (ROWS * TILE_WIDTH)) / 2);
	int tile_num = 0;

	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < ROWS; j++)
		{
			grid[tile_num].tile.set_position(start_pos + (j * TILE_WIDTH) + 48, start_pos + (i * TILE_WIDTH));
			grid[tile_num].x = i;
			grid[tile_num].y = j;
			tile_num++;
		}
	}	
}

void randomize_colors()
{
	srand(time(NULL));
	for (int i = 0; i < ROWS * ROWS; i++)
	{
		grid[i].color = rand() % NUM_COLORS;
	}
}

void fill_grid(int x, int y, int prev_color, int new_color)
{
	if (x < 0 || x >= ROWS || y < 0 || y >= ROWS)
		return;

	tile_t* current_tile = NULL;
	for (int i = 0; i < ROWS * ROWS; i++)
	{
		if (grid[i].x == x && grid[i].y == y)
		{
			current_tile = &grid[i];
		}
	}

	if (current_tile->color != prev_color)
		return;

	current_tile->color = new_color;

	int x_minus = x - 1;
	fill_grid(x_minus, y, prev_color, new_color);
	int x_plus = x + 1;
	fill_grid(x_plus, y, prev_color, new_color);
	int y_minus = y - 1;
	fill_grid(x, y_minus, prev_color, new_color);
	int y_plus = y + 1;
	fill_grid(x, y_plus, prev_color, new_color);

}

int reset_turns()
{
	float i = (50 * ROWS * NUM_COLORS) / 164;
	return i;
}

bool check_if_board_is_filled()
{
	int total_tiles = ROWS * ROWS;
	int count = 0;
	int color = grid[0].color;
	for (int i = 0; i < total_tiles; i++)
	{
		if (grid[i].color == color)
			count++;
	}
	if (count == total_tiles)
		return true;
	else return false;
}

int main(int argc, char* args[])
{
	srand(time(NULL));

	if (!initialize())
		printf("Failed to initialize.\n");
	else
	{
		printf("initialize complete!\n");

		if (!load_media())
			printf("Failed to load media.\n");

		else
		{
			printf("load media complete!\n");
			bool quit = false;
			SDL_Event game_event;

			make_grid();
			randomize_colors();

			int start_x = grid[0].x;
			int start_y = grid[0].y;
			int current_color = grid[0].color;
			int prev_color;
			int turns_left = reset_turns();
			int tile_start_pos = (SCREEN_WIDTH - (ROWS * TILE_WIDTH)) / 2;

			std::stringstream turns_text;
			std::stringstream rows_number;
			std::stringstream colors_number;

			const int ARROW_POS_X = 40;
			const int ROWS_MAX = 16;
			const int ROWS_MIN = 5;
			const int COLORS_MAX = 7;
			const int COLORS_MIN = 3;

			int rows_copy = ROWS;
			int colors_copy = NUM_COLORS;
			bool lost = false;

			arrow_button[0].set_position(ARROW_POS_X + 1, 140);
			arrow_button[1].set_position(ARROW_POS_X, 200);
			arrow_button[1].flip_button();
			arrow_button[2].set_position(ARROW_POS_X + 1, 290);
			arrow_button[3].set_position(ARROW_POS_X, 350);
			arrow_button[3].flip_button();

			reset_button.set_position(ARROW_POS_X, 390);

			while (!quit)
			{
				// game event loop:
				while (SDL_PollEvent(&game_event) != 0)
				{
					if (game_event.type == SDL_QUIT)
						quit = true;

					if (!lost)
					{
						for (int i = 0; i < ROWS * ROWS; i++)
						{
							grid[i].tile.handle_event(&game_event);
						}
					}

					for (int i = 0; i < 4; i++)
					{
						arrow_button[i].handle_event(&game_event);
					}

					if (arrow_button[0].been_pressed())
					{
						rows_copy++;
						if (rows_copy > ROWS_MAX)
						{
							rows_copy--;
						}
					}

					if (arrow_button[1].been_pressed())
					{
						rows_copy--;
						if (rows_copy < ROWS_MIN)
						{
							rows_copy++;
						}
					}

					if (arrow_button[2].been_pressed())
					{
						colors_copy++;
						if (colors_copy > COLORS_MAX)
						{
							colors_copy--;
						}
					}

					if (arrow_button[3].been_pressed())
					{
						colors_copy--;
						if (colors_copy < COLORS_MIN)
						{
							colors_copy++;
						}
					}

					reset_button.handle_event(&game_event);

					if (game_event.type == SDL_KEYDOWN || reset_button.been_pressed())
					{
						if (game_event.key.keysym.sym == SDLK_r || reset_button.been_pressed())
						{
							ROWS = rows_copy;
							NUM_COLORS = colors_copy;
							make_grid();
							randomize_colors();
							turns_left = reset_turns();
							start_x = grid[0].x;
							start_y = grid[0].y;
							current_color = grid[0].color;
							prev_color;
							lost = false;
						}
					}
				}

				// game render loop:
				SDL_SetRenderDrawColor(game_renderer, 0, 0, 0, 0);
				SDL_RenderClear(game_renderer);

				turns_text.str("");
				turns_text << "Turns left: " << turns_left;

				if (!TURNS_LEFT_TEXURE.load_from_rendered_text(turns_text.str().c_str(), text_color))
				{
					printf("Unable to render turns_left texture.\n");
				}

				rows_number.str("");
				rows_number << rows_copy;

				if (!ROWS_TEXTURE.load_from_rendered_text(rows_number.str().c_str(), text_color))
				{
					printf("Unable to render rows_number.\n");
				}

				colors_number.str("");
				colors_number << colors_copy;

				if (!COLORS_TEXTURE.load_from_rendered_text(colors_number.str().c_str(), text_color))
				{
					printf("Unable to render rows_number.\n");
				}

				for (int i = 0; i < 4; i++)
				{
					arrow_button[i].render();
				}

				FLOOD_IT_TEXTURE.render((SCREEN_WIDTH - FLOOD_IT_TEXTURE.get_width()) / 2, 30);
				TURNS_LEFT_TEXURE.render((SCREEN_WIDTH - TURNS_LEFT_TEXURE.get_width()) / 2, 500);
				ROWS_TEXT.render(40, 110);
				ROWS_TEXTURE.render(60, 172);
				COLORS_TEXT.render(24, 260);
				COLORS_TEXTURE.render(59, 323);
				reset_button.render();

				for (int i = 0; i < ROWS * ROWS; i++)
				{
					if (grid[i].tile.been_clicked())
					{
						grid[i].tile.reset_click();
						
						if (grid[i].color != current_color)
						{
							prev_color = current_color;
							current_color = grid[i].color;

							fill_grid(start_x, start_y, prev_color, current_color);
							turns_left--;
							if (turns_left < 0)
							{
								turns_left = 0;
							}
						}
					}

					grid[i].tile.render_tile(game_renderer, grid[i].color);
				}

				if (check_if_board_is_filled())
				{
					// you win
					WIN_TEXT.render(10, 10);
				}

				if (turns_left <= 0 && !check_if_board_is_filled())
				{
					// you lose
					LOSE_TEXT.render(10, 10);
					lost = true;
				}

				SDL_RenderPresent(game_renderer);
			}
		}
	}
	close();
	return 0;
}