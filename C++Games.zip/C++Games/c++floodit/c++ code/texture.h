#pragma once
#include "common.h"

class Texture_t
{
public:
	Texture_t();
	~Texture_t();
	bool load_from_file(std::string path);
	bool load_from_rendered_text(std::string textureText, SDL_Color textColor);
	void free();
	void set_color(Uint8 red, Uint8 green, Uint8 blue);
	void set_blend_mode(SDL_BlendMode blending);
	void set_alpha(Uint8 alpha);
	void render(int x, int y, SDL_Rect* clip = NULL, double angle = 0.0, SDL_Point* center = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE);
	int get_width();
	int get_height();

private:
	SDL_Texture* Texture;
	int width;
	int height;
};

