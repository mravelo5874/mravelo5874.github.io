#include "common.h"
#include "tile.h"

Tile::Tile()
{
	position.x = 0;
	position.y = 0;
	w = TILE_WIDTH;
	h = TILE_WIDTH;
	inside_tile = false;
	tile_clicked = false;
}

void Tile::set_position(int x, int y)
{
	position.x = x;
	position.y = y;
}

void Tile::render_tile(SDL_Renderer* game_renderer, int color)
{
	SDL_Rect fillRect = { position.x, position.y, w, h };
	if (color == 0) // red
	{
		SDL_SetRenderDrawColor(game_renderer, 255, 20, 20, 255);
	}
	else if (color == 1) // green
	{
		SDL_SetRenderDrawColor(game_renderer, 0, 200, 100, 255);
	}
	else if (color == 2) // blue
	{
		SDL_SetRenderDrawColor(game_renderer, 0, 100, 255, 255);
	}
	else if (color == 3) // yellow
	{
		SDL_SetRenderDrawColor(game_renderer, 255, 220, 0, 255);
	}
	else if (color == 4) // purple
	{
		SDL_SetRenderDrawColor(game_renderer, 150, 0, 190, 255);
	}
	else if (color == 5) // orange
	{
		SDL_SetRenderDrawColor(game_renderer, 255, 130, 60, 255);
	}
	else if (color == 6) // aqua
	{
		SDL_SetRenderDrawColor(game_renderer, 0, 220, 210, 255);
	}
	

	SDL_RenderFillRect(game_renderer, &fillRect);

	SDL_Rect outline = { position.x, position.y, w, h };
	SDL_SetRenderDrawColor(game_renderer, 0, 0, 0, 0);

	if (inside_tile)
	{
		SDL_SetRenderDrawColor(game_renderer, 255, 255, 255, 255);
	}
	SDL_RenderDrawRect(game_renderer, &outline);

}

void Tile::handle_event(SDL_Event* tile_event)
{
	if (tile_event->type == SDL_MOUSEMOTION)
	{
		reset_click();
		inside_tile = true;
		int x, y;
		SDL_GetMouseState(&x, &y);
		if (x < position.x)
			inside_tile = false;
		else if (x > position.x + w)
			inside_tile = false;
		else if (y < position.y)
			inside_tile = false;
		else if (y > position.y + h)
			inside_tile = false;
	}

	if (inside_tile)
	{
		if (tile_event->type == SDL_MOUSEBUTTONDOWN)
			tile_clicked = true;
	}
	if (tile_event->type == SDL_MOUSEBUTTONUP)
		reset_click();
}

void Tile::clear_tile()
{
	//
}

void Tile::reset_click()
{
	tile_clicked = false;
}

bool Tile::been_clicked()
{
	return tile_clicked;
}