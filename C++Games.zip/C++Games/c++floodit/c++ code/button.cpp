#include "common.h"
#include "button.h"

Button_t::Button_t()
{
	position.x = 0;
	position.y = 0;
	sprites[0] = NULL;
	sprites[1] = NULL;
	current_sprite = NULL;
	pushed = false;
	width_height.x = 0;
	width_height.y = 0;
	flipped = false;
}

void Button_t::set_position(int x, int y)
{
	position.x = x;
	position.y = y;
}

void Button_t::handle_event(SDL_Event* button_event)
{

	if (button_event->type == SDL_MOUSEMOTION || button_event->type == SDL_MOUSEBUTTONDOWN || button_event->type == SDL_MOUSEBUTTONUP)
	{
		int x, y;
		SDL_GetMouseState(&x, &y);
		bool inside = true;
		if (x < position.x)
			inside = false;
		else if (x > position.x + width_height.x)
			inside = false;
		else if (y < position.y)
			inside = false;
		else if (y > position.y + width_height.y)
			inside = false;

		if (inside)
		{
			if (button_event->type == SDL_MOUSEBUTTONDOWN)
			{
				pushed = true;
			}
			if (button_event->type == SDL_MOUSEBUTTONUP)
			{
				reset_button();
			}
		}
	}
}

void Button_t::render()
{
	current_sprite = sprites[0];
	double angle = 0.0;

	if (pushed)
	{
		current_sprite = sprites[1];
	}
	if (flipped)
	{
		angle = 180.0;
	}

	button_texture->render(position.x, position.y, current_sprite, angle);
}

bool Button_t::been_pressed()
{
	return pushed;
}

void Button_t::reset_button()
{
	pushed = false;
}

void Button_t::set_texture(Texture_t* t)
{
	if (&t != NULL)
		button_texture = t;
}

void Button_t::set_sprite(SDL_Rect* s, int i)
{
	if (&s != NULL)
		sprites[i] = s;
}

void Button_t::set_button_width_height(int w, int h)
{
	width_height.x = w;
	width_height.y = h;
}

void Button_t::flip_button()
{
	if (flipped)
		flipped = false;
	else if (!flipped)
		flipped = true;
}