Here's how to download and play a game:
1) Download the .zip file.	
2) Right click and extract it onto your computer.
3) Open the folder of the game you want to try out.	
4) Run the application.	