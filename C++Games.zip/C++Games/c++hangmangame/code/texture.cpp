#include "texture.h"
#include "common.h"

Texture_t::Texture_t()
{
	texture = NULL;
	width = 0;
	height = 0;
}

Texture_t::~Texture_t()
{
	free_texture();
}

bool Texture_t::load_from_file(std::string path)
{
	free_texture();
	SDL_Texture* new_texture = NULL;
	SDL_Surface * loaded_surface = IMG_Load(path.c_str());
	if (loaded_surface == NULL)
		printf("Unable to load image %s. SDL_image ERROR: %s\n", path.c_str(), IMG_GetError());
	else
	{
		SDL_SetColorKey(loaded_surface, SDL_TRUE, SDL_MapRGB(loaded_surface->format, 30, 218, 2));
		new_texture = SDL_CreateTextureFromSurface(game_renderer, loaded_surface);
		if (new_texture == NULL)
			printf("Unable t0 create texture from %s. SDL ERROR: %s\n", path.c_str(), SDL_GetError());
		else
		{
			width = loaded_surface->w;
			height = loaded_surface->h;
		}
		SDL_FreeSurface(loaded_surface);
	}
	texture = new_texture;
	return texture != NULL;
}

bool Texture_t::load_from_rendered_text(const char* letter, SDL_Color text_color)
{
	free_texture();
	SDL_Surface * text_surface = TTF_RenderText_Solid(game_font, letter, text_color);
	if (text_surface != NULL)
	{
		texture = SDL_CreateTextureFromSurface(game_renderer, text_surface);
		if (texture == NULL)
			printf("Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError());
		else
		{
			width = text_surface->w;
			height = text_surface->h;
		}
		SDL_FreeSurface(text_surface);
	}
	else
		printf("Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError());
	return texture != NULL;
}

void Texture_t::free_texture()
{
	if (texture != NULL)
	{
		SDL_DestroyTexture(texture);
		texture = NULL;
		width = 0;
		height = 0;
	}
}

void Texture_t::set_color(Uint8 red, Uint8 green, Uint8 blue)
{
	SDL_SetTextureColorMod(texture, red, green, blue);
}

void Texture_t::set_blend_mode(SDL_BlendMode blending)
{
	SDL_SetTextureBlendMode(texture, blending);
}

void Texture_t::set_alpha(Uint8 alpha)
{
	SDL_SetTextureAlphaMod(texture, alpha);
}

void Texture_t::render_texture(int x, int y, SDL_Rect* clip, double angle, SDL_Point* center, SDL_RendererFlip flip)
{
	SDL_Rect renderQuad = { x, y, width, height };
	if (clip != NULL)
	{
		renderQuad.w = clip->w;
		renderQuad.h = clip->h;
	}
	SDL_RenderCopyEx(game_renderer, texture, clip, &renderQuad, angle, center, flip);
}

int Texture_t::get_width()
{
	return width;
}

int Texture_t::get_height()
{
	return height;
}