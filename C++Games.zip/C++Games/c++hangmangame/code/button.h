#pragma once
#include <SDL_image.h>
#include "texture.h"

class Button_t
{
public:
	Button_t();
	void set_position(int x, int y);
	void handle_event(SDL_Event* button_event);
	void render();
	bool been_pressed();
	void reset_button();
	void set_texture(Texture_t* t);
	void set_sprite(SDL_Rect* s, int i);
	void set_button_width_height(int w, int h);
	void clear_button();
private:
	SDL_Point position;
	SDL_Point width_height;
	bool pushed;
	SDL_Rect* sprites[2];
	SDL_Rect* current_sprite;
	Texture_t* button_texture;
};
