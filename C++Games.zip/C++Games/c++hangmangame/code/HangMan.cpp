#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <stdio.h>
#include <string>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "common.h"
#include "texture.h"
#include "button.h"

#define MAX_SIZE 100
const int NUM_WORDS_IN_LIST = 25;

const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

const int BUTTON_WIDTH = 240;
const int BUTTON_HEIGHT = 60;
const int TOTAL_BUTTONS = 3;
const int SPRITES_PER_BUTTON = 2;

SDL_Window* game_window = NULL;
SDL_Renderer* game_renderer = NULL;

SDL_Color text_color = { 0, 0, 0 };
TTF_Font* game_font = NULL;

bool initialize();
bool load_media();
void close();

//animated textures:
const int HUNG_ANIMATION_FRAMES = 7;
SDL_Rect hung_boi_clips[HUNG_ANIMATION_FRAMES];
Texture_t hung_boi_texture;

const int ALPHA_FRAMES = 27;
SDL_Rect alpha_clips[ALPHA_FRAMES];
SDL_Rect small_alpha_clips[ALPHA_FRAMES];
SDL_Rect num_clips[10];
Texture_t alpha_texture;

//buttons:
Texture_t start_texture;
SDL_Rect start_sprites[SPRITES_PER_BUTTON];
Button_t start_button;

Texture_t options_texture;
SDL_Rect options_sprites[SPRITES_PER_BUTTON];
Button_t options_button;

Texture_t easy_texture;
SDL_Rect easy_sprites[SPRITES_PER_BUTTON];
Button_t easy_button;

Texture_t med_texture;
SDL_Rect med_sprites[SPRITES_PER_BUTTON];
Button_t med_button;

Texture_t hard_texture;
SDL_Rect hard_sprites[SPRITES_PER_BUTTON];
Button_t hard_button;

Texture_t back_texture;
SDL_Rect back_sprites[SPRITES_PER_BUTTON];
Button_t back_button;

Texture_t on_off_texture;
SDL_Rect on_off_sprites[SPRITES_PER_BUTTON];
Button_t on_off_button;
//screens:
Texture_t menu_screen;
Texture_t options_screen;
Texture_t difficulty_screen;
Texture_t game_screen;
Texture_t win_screen;
Texture_t lose_screen;

// developer mode is off by default
bool dev_mode = false;

bool initialize()
{
	bool success = true;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize. SDL ERROR: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		if (!SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1"))
			printf("Warning: Linear texture filtering not enabled!");
	}
	game_window = SDL_CreateWindow("SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	if (game_window == NULL)
	{
		printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		game_renderer = SDL_CreateRenderer(game_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
		if (game_renderer == NULL)
		{
			printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
			int imgFlags = IMG_INIT_PNG;
			if (!(IMG_Init(imgFlags) & imgFlags))
			{
				printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
				success = false;
			}
			if (TTF_Init() == -1)
			{
				printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
				success = false;
			}
		}
	}
	return success;
}

bool load_media()
{
	bool success = true;

	if (!menu_screen.load_from_file("pngs/menu_screen.png"))
	{
		printf("Failed to load menu_screen texture\n");
		success = false;
	}

	if (!options_screen.load_from_file("pngs/options_menu.png"))
	{
		printf("Failed to load options_screen texture.\n");
		success = false;
	}
	
	if (!difficulty_screen.load_from_file("pngs/difficulty_screen.png"))
	{
		printf("Failed to load difficulty_screen texture.\n");
		success = false;
	}

	if (!game_screen.load_from_file("pngs/game_screen.png"))
	{
		printf("Failed to load difficulty_screen texture.\n");
		success = false;
	}

	if (!win_screen.load_from_file("pngs/win_screen.png"))
	{
		printf("Failed to load win_screen texture\n");
		success = false;
	}

	if (!lose_screen.load_from_file("pngs/lose_screen.png"))
	{
		printf("Failed to load lose_screen texture\n");
		success = false;
	}

	if (!start_texture.load_from_file("pngs/start_button_sprites.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			start_sprites[i].x = 0;
			start_sprites[i].y = i * 60;
			start_sprites[i].w = BUTTON_WIDTH;
			start_sprites[i].h = BUTTON_HEIGHT;
		}
		start_button.set_position(60, 360);
		start_button.set_texture(&start_texture);
		start_button.set_sprite(&start_sprites[0], 0);
		start_button.set_sprite(&start_sprites[1], 1);
		start_button.set_button_width_height(BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	if (!options_texture.load_from_file("pngs/option_button_sprites.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			options_sprites[i].x = 0;
			options_sprites[i].y = i * 60;
			options_sprites[i].w = BUTTON_WIDTH;
			options_sprites[i].h = BUTTON_HEIGHT;
		}
		options_button.set_position(340, 360);
		options_button.set_texture(&options_texture);
		options_button.set_sprite(&options_sprites[0], 0);
		options_button.set_sprite(&options_sprites[1], 1);
		options_button.set_button_width_height(BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	if (!easy_texture.load_from_file("pngs/easy_button_sprites.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			easy_sprites[i].x = 0;
			easy_sprites[i].y = i * 60;
			easy_sprites[i].w = BUTTON_WIDTH;
			easy_sprites[i].h = BUTTON_HEIGHT;
		}
		easy_button.set_texture(&easy_texture);
		easy_button.set_sprite(&easy_sprites[0], 0);
		easy_button.set_sprite(&easy_sprites[1], 1);
		easy_button.set_button_width_height(BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	if (!med_texture.load_from_file("pngs/med_button_sprites.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			med_sprites[i].x = 0;
			med_sprites[i].y = i * 60;
			med_sprites[i].w = BUTTON_WIDTH;
			med_sprites[i].h = BUTTON_HEIGHT;
		}
		med_button.set_texture(&med_texture);
		med_button.set_sprite(&med_sprites[0], 0);
		med_button.set_sprite(&med_sprites[1], 1);
		med_button.set_button_width_height(BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	if (!hard_texture.load_from_file("pngs/hard_button_sprites.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			hard_sprites[i].x = 0;
			hard_sprites[i].y = i * 60;
			hard_sprites[i].w = BUTTON_WIDTH;
			hard_sprites[i].h = BUTTON_HEIGHT;
		}
		hard_button.set_texture(&hard_texture);
		hard_button.set_sprite(&hard_sprites[0], 0);
		hard_button.set_sprite(&hard_sprites[1], 1);
		hard_button.set_button_width_height(BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	if (!back_texture.load_from_file("pngs/back_button_sprite.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			back_sprites[i].x = 0;
			back_sprites[i].y = i * 52;
			back_sprites[i].w = 52;
			back_sprites[i].h = 52;
		}
		back_button.set_position(580, 0);
		back_button.set_texture(&back_texture);
		back_button.set_sprite(&back_sprites[0], 0);
		back_button.set_sprite(&back_sprites[1], 1);
		back_button.set_button_width_height(52, 52);
	}
	
	if (!on_off_texture.load_from_file("pngs/off_on_button.png"))
	{
		printf("Failed to load button_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < SPRITES_PER_BUTTON; i++)
		{
			on_off_sprites[i].x = 0;
			on_off_sprites[i].y = i * 24;
			on_off_sprites[i].w = 42;
			on_off_sprites[i].h = 26;
		}
		on_off_button.set_texture(&on_off_texture);
		on_off_button.set_sprite(&on_off_sprites[0], 0);
		on_off_button.set_sprite(&on_off_sprites[1], 1);
		on_off_button.set_button_width_height(42, 26);
	}

	if (!hung_boi_texture.load_from_file("pngs/hung_boi_sprites.png"))
	{
		printf("Failed to load hung_boi sprite texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < HUNG_ANIMATION_FRAMES; i++)
		{
			hung_boi_clips[i].x = i * 55;
			hung_boi_clips[i].y = 0;
			hung_boi_clips[i].w = 55;
			hung_boi_clips[i].h = 65;
		}
	}

	game_font = TTF_OpenFont("png/AtariST8x16SystemFont.ttf", 64);
	if (game_font = NULL)
	{
		printf("Failed to load in game_font. SDL_ttf ERROR: %s\n", TTF_GetError());
		success = false;
	}

	if (!alpha_texture.load_from_file("pngs/letters_sprites.png"))
	{
		printf("Failed to load in alpha_texture.\n");
		success = false;
	}
	else
	{
		for (int i = 0; i < ALPHA_FRAMES; i++)
		{
			alpha_clips[i].x = 0;
			alpha_clips[i].y = i * 53;
			alpha_clips[i].w = 46;
			alpha_clips[i].h = 52;
		}
		for (int i = 0; i < ALPHA_FRAMES; i++)
		{
			small_alpha_clips[i].x = 47;
			small_alpha_clips[i].y = i * 14;
			small_alpha_clips[i].w = 10;
			small_alpha_clips[i].h = 14;
		}
		for (int i = 0; i < 10; i++)
		{
			num_clips[i].x = 57;
			num_clips[i].y = i * 14;
			num_clips[i].w = 11;
			num_clips[i].h = 14;
		}
	}

	return success;
}

void close()
{
	TTF_CloseFont(game_font);
	
	//Free loaded textures

	start_texture.free_texture();
	options_texture.free_texture();
	easy_texture.free_texture();
	back_texture.free_texture();
	alpha_texture.free_texture();

	menu_screen.free_texture();
	options_screen.free_texture();
	difficulty_screen.free_texture();
	game_screen.free_texture();
	hung_boi_texture.free_texture();
	win_screen.free_texture();
	lose_screen.free_texture();

	TTF_CloseFont(game_font);
	game_font = NULL;
	SDL_DestroyRenderer(game_renderer);
	SDL_DestroyWindow(game_window);
	game_window = NULL;
	game_renderer = NULL;
	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

std::string choose_a_word(int difficulty)
{
	const std::string easy_words[MAX_SIZE] =
	{
		"frog",
		"duck",
		"sumo",
		"list",
		"suck",
		"jazz",
		"iron",
		"neck",
		"exit",
		"fork", // 10
		"fast",
		"bird",
		"room",
		"wolf",
		"trap",
		"nest",
		"free",
		"vote",
		"baby",
		"poem", // 20
		"time",
		"lace",
		"echo",
		"wild",
		"wine"  // 25
	};
	const std::string medium_words[MAX_SIZE] =
	{
		"notepad",
		"desktop",
		"swimmer",
		"wallpaper",
		"computer",
		"concept",
		"victory",
		"partner",
		"morning",
		"revenge", // 10
		"captain",
		"freckle",
		"default",
		"nuclear",
		"sweater",
		"alchohol",
		"gallery",
		"sunrise",
		"factory",
		"lighter", // 20
		"royalty",
		"harmony",
		"missile",
		"pottery",
		"diagram"  // 25
	};
	const std::string hard_words[MAX_SIZE] =
	{
		"dictionary",
		"algorithm",
		"calculator",
		"sketchbook",
		"equation",
		"reproduction",
		"conglomerate",
		"experienced",
		"application",
		"personality", // 10
		"comprehensive",
		"constellation",
		"institution",
		"hypothesize",
		"temperature",
		"countryside",
		"intelligence",
		"environment",
		"neighborhood",
		"anticipation", // 20
		"electronics",
		"sympathetic",
		"synthesizer",
		"battlefield",
		"revolutionary" // 25
	};

	std::string word;
	srand(time(NULL));

	if (difficulty == 1)
		word = easy_words[rand() % NUM_WORDS_IN_LIST];
	else if (difficulty == 2)
		word = medium_words[rand() % NUM_WORDS_IN_LIST];
	else if (difficulty == 3)
		word = hard_words[rand() % NUM_WORDS_IN_LIST];
	return word;
}

int convert_key_to_char_int(SDL_Event game_event)
{
	switch (game_event.key.keysym.sym)
	{
	case SDLK_a:
		return 1;
	case SDLK_b:
		return 2;
	case SDLK_c:
		return 3;
	case SDLK_d:
		return 4;
	case SDLK_e:
		return 5;
	case SDLK_f:
		return 6;
	case SDLK_g:
		return 7;
	case SDLK_h:
		return 8;
	case SDLK_i:
		return 9;
	case SDLK_j:
		return 10;
	case SDLK_k:
		return 11;
	case SDLK_l:
		return 12;
	case SDLK_m:
		return 13;
	case SDLK_n:
		return 14;
	case SDLK_o:
		return 15;
	case SDLK_p:
		return 16;
	case SDLK_q:
		return 17;
	case SDLK_r:
		return 18;
	case SDLK_s:
		return 19;
	case SDLK_t:
		return 20;
	case SDLK_u:
		return 21;
	case SDLK_v:
		return 22;
	case SDLK_w:
		return 23;
	case SDLK_x:
		return 24;
	case SDLK_y:
		return 25;
	case SDLK_z:
		return 26;
	default:
		return 0;
	}
}

int convert_char_to_int(char letter)
{
	switch (letter)
	{
	case 'a':
		return 1;
	case 'b':
		return 2;
	case 'c':
		return 3;
	case 'd':
		return 4;
	case 'e':
		return 5;
	case 'f':
		return 6;
	case 'g':
		return 7;
	case 'h':
		return 8;
	case 'i':
		return 9;
	case 'j':
		return 10;
	case 'k':
		return 11;
	case 'l':
		return 12;
	case 'm':
		return 13;
	case 'n':
		return 14;
	case 'o':
		return 15;
	case 'p':
		return 16;
	case 'q':
		return 17;
	case 'r':
		return 18;
	case 's':
		return 19;
	case 't':
		return 20;
	case 'u':
		return 21;
	case 'v':
		return 22;
	case 'w':
		return 23;
	case 'x':
		return 24;
	case 'y':
		return 25;
	case 'z':
		return 26;
	default:
		return 0;
	}
}

bool game(std::string word)
{
	if (dev_mode)
		printf("word = %s\nword_length = %i", word.c_str(), word.length());

	bool in_game = true;
	SDL_Event in_game_event;
	int hung_boi_frame = 0;
	int letter_num = 0;
	int guessed_letter_nums[MAX_SIZE] = { 0 };
	int next_in_list = 0;
	int trys_remaining = 6;

	int word_size = word.length();
	int x_first_letter = (SCREEN_WIDTH - (46 * word_size)) / 2;
	bool letter_was_guessed[MAX_SIZE] = { false };

	while (in_game)
	{
		while (SDL_PollEvent(&in_game_event) != 0)
		{
			if (in_game_event.type == SDL_QUIT)
			{
				in_game = false;
			}

			if (in_game_event.type == SDL_KEYDOWN)
			{
				if (letter_num == 0)
					letter_num = convert_key_to_char_int(in_game_event);
				if (in_game_event.key.keysym.sym == SDLK_BACKSPACE)
					letter_num = 0;
				if (letter_num != 0)
				{
					if (in_game_event.key.keysym.sym == SDLK_SPACE)
					{
						bool repeat_letter = false;
						if (letter_num != '0')
						{
							int i = 0;
							while (guessed_letter_nums[i] != '\0')
							{
								if (guessed_letter_nums[i] == letter_num)
								{
									repeat_letter = true;
									if (dev_mode)
										printf("repeat letter!\n");
								}
								i++;
							}

							if (!repeat_letter)
							{
								guessed_letter_nums[next_in_list] = letter_num;
								next_in_list++;

								bool in_word = false;
								for (int i = 0; i < word_size; i++)
								{
									int letter = convert_char_to_int(word.at(i));
									if (letter == letter_num)
									{
										if (dev_mode)
											printf("letter is in word!\n");
										in_word = true;
										letter_was_guessed[i] = true;
									}
								}
								if (!in_word)
									trys_remaining--;
							}
							if (dev_mode)
								printf("trys_remaining = %i\n", trys_remaining);
							letter_num = 0;
						}
					}
				}
			}
		}
		SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
		SDL_RenderClear(game_renderer);

		game_screen.render_texture(0, 0);

		SDL_Rect* current_alpha = &small_alpha_clips[0];
		int i = 0;
		while (guessed_letter_nums[i] != 0)
		{
			int i_copy = i;
			int y = 55;
			if (i >= 10)
			{
				y = y + 20;
				i_copy = i - 10;
				if (i >= 20)
				{
					y = y + 20;
					i_copy = i - 20;
				}
			}
			current_alpha = &small_alpha_clips[guessed_letter_nums[i]];
			alpha_texture.render_texture(33 + (20 * i_copy), y, current_alpha);
			i++;
		}

		hung_boi_frame = 6 - trys_remaining;
		SDL_Rect* current_clip = &hung_boi_clips[hung_boi_frame];
		hung_boi_texture.render_texture(450, 100, current_clip);

		current_alpha = &num_clips[trys_remaining];
		alpha_texture.render_texture(510, 40, current_alpha);

		current_alpha = &alpha_clips[0];
		for (int i = 0; i < word_size; i++)
		{
			if (!letter_was_guessed[i])
			{
				current_alpha = &alpha_clips[0];
			}
			else
			{
				current_alpha = &alpha_clips[convert_char_to_int(word.at(i))];
			}
			alpha_texture.render_texture(x_first_letter + (46 * i), 280, current_alpha);
		}

		current_alpha = &alpha_clips[letter_num];
		alpha_texture.render_texture(437, 372, current_alpha);

		int got = 0;
		for (int i = 0; i < word_size; i++)
		{
			if (letter_was_guessed[i] == true)
				got++;
		}
		if (got == word_size)
		{
			win_screen.render_texture(0, 0);
			SDL_RenderPresent(game_renderer);

			while (in_game)
			{
				while (SDL_PollEvent(&in_game_event) != 0)
				{
					if (in_game_event.type == SDL_QUIT)
					{
						in_game = false;
						return true;
					}

					if (in_game_event.type == SDL_KEYDOWN)
					{
						in_game = false;
						return false;
					}
				}
			}
		}
		if (trys_remaining == 0)
		{
			lose_screen.render_texture(0, 0);
			SDL_RenderPresent(game_renderer);

			while (in_game)
			{
				while (SDL_PollEvent(&in_game_event) != 0)
				{
					if (in_game_event.type == SDL_QUIT)
					{
						in_game = false;
						return true;
					}

					if (in_game_event.type == SDL_KEYDOWN)
					{
						in_game = false;
						return false;
					}
				}
			}
		}
		SDL_RenderPresent(game_renderer);
	}

	return true;
}

bool difficulty_menu()
{
	bool in_difficulty_menu = true;
	SDL_Event difficulty_event;
	while (in_difficulty_menu)
	{
		while (SDL_PollEvent(&difficulty_event) != 0)
		{
			if (difficulty_event.type == SDL_QUIT)
			{
				return true;
			}

			easy_button.handle_event(&difficulty_event);

			if (easy_button.been_pressed() == true)
			{
				easy_button.reset_button();

				if (dev_mode)
					printf("easy button has been pressed.\n");

				std::string word = choose_a_word(1);
				return game(word);
			}

			med_button.handle_event(&difficulty_event);

			if (med_button.been_pressed() == true)
			{
				med_button.reset_button();

				if (dev_mode)
					printf("med button has been pressed.\n");

				std::string word = choose_a_word(2);
				return game(word);
			}

			hard_button.handle_event(&difficulty_event);

			if (hard_button.been_pressed() == true)
			{
				hard_button.reset_button();

				if (dev_mode)
					printf("hard button has been pressed.\n");

				std::string word = choose_a_word(3);
				return game(word);
			}

			back_button.handle_event(&difficulty_event);

			if (back_button.been_pressed() == true)
			{
				back_button.reset_button();

				if (dev_mode)
					printf("back button has been pressed.\n");

				in_difficulty_menu = false;
			}
		}
		SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
		SDL_RenderClear(game_renderer);

		difficulty_screen.render_texture(0, 0);

		easy_button.set_position(200,200);
		easy_button.render();

		med_button.set_position(200,280);
		med_button.render();

		hard_button.set_position(200,360);
		hard_button.render();

		back_button.render();

		SDL_RenderPresent(game_renderer);
	}
	
	return false;
}

bool options_menu()
{
	bool in_options_menu = true;
	SDL_Event options_event;
	while (in_options_menu)
	{
		while (SDL_PollEvent(&options_event) != 0)
		{
			if (options_event.type == SDL_QUIT)
			{
				return true;
			}

			back_button.handle_event(&options_event);
			if (back_button.been_pressed())
			{
				back_button.reset_button();

				if (dev_mode)
					printf("back button has been pressed.\n");
				in_options_menu = false;
			}

			on_off_button.handle_event(&options_event);
			if (on_off_button.been_pressed())
			{
				on_off_button.reset_button();

				if (!dev_mode)
				{
					dev_mode = true;
					printf("dev_mode turned on.\n");
					on_off_button.set_sprite(&on_off_sprites[0], 1);
					on_off_button.set_sprite(&on_off_sprites[1], 0);
				}
				else if (dev_mode)
				{
					dev_mode = false;
					printf("dev_mode turned off.\n");
					on_off_button.set_sprite(&on_off_sprites[0], 0);
					on_off_button.set_sprite(&on_off_sprites[1], 1);
				}	
			}
		}
		SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
		SDL_RenderClear(game_renderer);

		options_screen.render_texture(0, 0);
		back_button.render();

		on_off_button.set_position(210, 354);
		on_off_button.render();

		SDL_RenderPresent(game_renderer);
		
	}
	return false;
}

int main(int argc, char* args[])
{
	if (!initialize())
		printf("Failed to initialize.\n");
	else
	{
		printf("initialize complete!\n");
		if (!load_media())
			printf("Failed to load media.\n");
		else
		{
			printf("load media complete!\n");
			bool quit = false;
			SDL_Event game_event;
			int frame = 0;

			int next = 0;

			while (!quit)
			{
				//Game Loop:
				while (SDL_PollEvent(&game_event) != 0)
				{
					if (game_event.type == SDL_QUIT)
						quit = true;

					start_button.handle_event(&game_event);
					if (start_button.been_pressed() == true)
					{
						start_button.reset_button();

						//go to the difficulty menu
						if (dev_mode)
							printf("start button has been pressed.\n");

						quit = difficulty_menu();
					}
					
					options_button.handle_event(&game_event);
					if (options_button.been_pressed() == true)
					{
						options_button.reset_button();

						// go to the options menu
						if (dev_mode)
							printf("options button has been pressed.\n");

						quit = options_menu();
					}
				}
				//game shit happens here
				SDL_SetRenderDrawColor(game_renderer, 0xFF, 0xFF, 0xFF, 0xFF);
				SDL_RenderClear(game_renderer);

				menu_screen.render_texture(0, 0);

				start_button.render();
				options_button.render();

				SDL_Rect* current_clip = &hung_boi_clips[frame / 24];
				hung_boi_texture.render_texture((SCREEN_WIDTH / 2) - 27, 150, current_clip);

				if (dev_mode)
				{
					SDL_Rect* current_alpha = &alpha_clips[next / 10];
					alpha_texture.render_texture(600, 50, current_alpha);

					current_alpha = &small_alpha_clips[next / 10];
					alpha_texture.render_texture(550, 50, current_alpha);

					current_alpha = &num_clips[frame / 10];
					alpha_texture.render_texture(430, 50, current_alpha);
				}

				SDL_RenderPresent(game_renderer);

				frame++;
				if (frame / 24 >= HUNG_ANIMATION_FRAMES)
				{
					frame = 0;
				}
				next++;
				if (next / 10 >= ALPHA_FRAMES)
				{
					next = 0;
				}
			}
		}
	}
	close();
	return 0;
}