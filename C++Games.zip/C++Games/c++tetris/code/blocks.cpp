#include "blocks.h"

// L rotations:
int L1[4][4] =
{
	0, 0, 0, 0,
	1, 1, 1, 0,
	1, 0, 0, 0,
	0, 0, 0, 0
};

int L2[4][4] =
{
	1, 1, 0, 0,
	0, 1, 0, 0,
	0, 1, 0, 0,
	0, 0, 0, 0
};

int L3[4][4] =
{
	0, 0, 1, 0,
	1, 1, 1, 0,
	0, 0, 0, 0,
	0, 0, 0, 0
};

int L4[4][4] =
{
	0, 1, 0, 0,
	0, 1, 0, 0,
	0, 1, 1, 0,
	0, 0, 0, 0
};

// L_mirrored rotations:
int L1_m[4][4] =
{
	0, 0, 0, 0,
	1, 1, 1, 0,
	0, 0, 1, 0,
	0, 0, 0, 0
};

int L2_m[4][4] =
{
	0, 1, 0, 0,
	0, 1, 0, 0,
	1, 1, 0, 0,
	0, 0, 0, 0
};

int L3_m[4][4] =
{
	1, 0, 0, 0,
	1, 1, 1, 0,
	0, 0, 0, 0,
	0, 0, 0, 0
};

int L4_m[4][4] =
{
	0, 1, 1, 0,
	0, 1, 0, 0,
	0, 1, 0, 0,
	0, 0, 0, 0
};

// square:
int square1[4][4] =
{
	0, 0, 0, 0,
	1, 1, 0, 0,
	1, 1, 0, 0,
	0, 0, 0, 0
};

// S rotations:
int S1[4][4] =
{
	0, 0, 0, 0,
	0, 1, 1, 0,
	1, 1, 0, 0,
	0, 0, 0, 0
	
};

int S2[4][4] =
{
	0, 0, 0, 0,
	1, 0, 0, 0,
	1, 1, 0, 0,
	0, 1, 0, 0
	
};

// S_mirrored rotations:
int S1_m[4][4] =
{
	0, 0, 0, 0,
	1, 1, 0, 0,
	0, 1, 1, 0,
	0, 0, 0, 0
	
};

int S2_m[4][4] =
{
	0, 0, 0, 0,
	0, 1, 0, 0,
	1, 1, 0, 0,
	1, 0, 0, 0
	
};

// T rotations:
int T1[4][4] =
{
	0, 0, 0, 0,
	1, 1, 1, 0,
	0, 1, 0, 0,
	0, 0, 0, 0
};

int T2[4][4] =
{
	0, 1, 0, 0,
	1, 1, 0, 0,
	0, 1, 0, 0,
	0, 0, 0, 0
};

int T3[4][4] =
{
	0, 1, 0, 0,
	1, 1, 1, 0,
	0, 0, 0, 0,
	0, 0, 0, 0
};

int T4[4][4] =
{
	0, 1, 0, 0,
	0, 1, 1, 0,
	0, 1, 0, 0,
	0, 0, 0, 0
};

// line rotations:
int line1[4][4] =
{
	0, 0, 0, 0,
	1, 1, 1, 1,
	0, 0, 0, 0,
	0, 0, 0, 0
};

int line2[4][4] =
{
	0, 1, 0, 0,
	0, 1, 0, 0,
	0, 1, 0, 0,
	0, 1, 0, 0
};

/*
----------------------------------------------------------------
|															   |
|					class: Blocks							   |
----------------------------------------------------------------
*/

Blocks::Blocks()
{
	b.type = L;
	b.rotation = 1;
	b.width_height.x = 3;
	b.width_height.y = 2;
	start_x = 4;
	start_y = 0;
	b.block_start.x = 0;
	b.block_start.y = 1;
	b.red = 255;
	b.green = 255;
	b.blue = 255;
}

void Blocks::randomize_block()
{
	srand(time(NULL));
	int i = rand() % 7 + 1;

	if (i == 1)
	{
		b.type = L;
		b.width_height.x = 3;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 2)
	{
		b.type = L_mirrored;
		b.width_height.x = 3;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 3)
	{
		b.type = square;
		b.width_height.x = 2;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 4)
	{
		b.type = S;
		b.width_height.x = 3;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 5)
	{
		b.type = S_mirrored;
		b.width_height.x = 3;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 6)
	{
		b.type = T;
		b.width_height.x = 3;
		b.width_height.y = 2;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
	else if (i == 7)
	{
		b.type = line;
		b.width_height.x = 4;
		b.width_height.y = 1;
		b.block_start.x = 0;
		b.block_start.y = 1;
	}
}

void Blocks::randomize_color()
{
	srand(time(NULL));
	b.red = rand() % 255;
	b.green = rand() % 255;
	b.blue = rand() % 255;
}

int Blocks::get_red()
{
	return b.red;
}

int Blocks::get_green()
{
	return b.green;
}

int Blocks::get_blue()
{
	return b.blue;
}

bool Blocks::is_block(int x, int y)
{
	int(*block_array)[4][4] = NULL;

	if (b.type == L)
	{
		if (b.rotation == 1)
			block_array = &L1;
		else if (b.rotation == 2)
			block_array = &L2;
		else if (b.rotation == 3)
			block_array = &L3;
		else if (b.rotation == 4)
			block_array = &L4;
	}
	else if (b.type == L_mirrored)
	{
		if (b.rotation == 1)
			block_array = &L1_m;
		else if (b.rotation == 2)
			block_array = &L2_m;
		else if (b.rotation == 3)
			block_array = &L3_m;
		else if (b.rotation == 4)
			block_array = &L4_m;
	}
	else if (b.type == square)
	{
		block_array = &square1;
	}
	else if (b.type == S)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &S1;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &S2;
	}
	else if (b.type == S_mirrored)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &S1_m;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &S2_m;
	}
	else if (b.type == T)
	{
		if (b.rotation == 1)
			block_array = &T1;
		else if (b.rotation == 2)
			block_array = &T2;
		else if (b.rotation == 3)
			block_array = &T3;
		else if (b.rotation == 4)
			block_array = &T4;
	}
	else if (b.type == line)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &line1;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &line2;
	}

	if ((*block_array)[y][x] == 1)
		return true;
	else return false;
}

Blocks::~Blocks()
{

}

void Blocks::print_block(std::vector<std::vector<int>> &grid)
{
	int(*block_array)[4][4] = NULL;

	clear_grid(grid);

	if (b.type == L)
	{
		if (b.rotation == 1)
			block_array = &L1;
		else if (b.rotation == 2)
			block_array = &L2;
		else if (b.rotation == 3)
			block_array = &L3;
		else if (b.rotation == 4)
			block_array = &L4;
	}
	else if (b.type == L_mirrored)
	{
		if (b.rotation == 1)
			block_array = &L1_m;
		else if (b.rotation == 2)
			block_array = &L2_m;
		else if (b.rotation == 3)
			block_array = &L3_m;
		else if (b.rotation == 4)
			block_array = &L4_m;
	}
	else if (b.type == square)
	{
		block_array = &square1;
	}
	else if (b.type == S)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &S1;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &S2;
	}
	else if (b.type == S_mirrored)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &S1_m;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &S2_m;
	}
	else if (b.type == T)
	{
		if (b.rotation == 1)
			block_array = &T1;
		else if (b.rotation == 2)
			block_array = &T2;
		else if (b.rotation == 3)
			block_array = &T3;
		else if (b.rotation == 4)
			block_array = &T4;
	}
	else if (b.type == line)
	{
		if (b.rotation == 1 || b.rotation == 3)
			block_array = &line1;
		else if (b.rotation == 2 || b.rotation == 4)
			block_array = &line2;
	}
	int y_pos = start_y;
	for (int i = 0; i < 4; i++)
	{
		int x_pos = start_x;

		for (int j = 0; j < 4; j++)
		{
			if ((*block_array)[i][j] == 1)
			{
				grid[x_pos][y_pos] = 1;
			}
			x_pos++;
		}
		y_pos++;
	}
	return;
}

int Blocks::get_block_type()
{
	return b.type;
}

int Blocks::get_x_start()
{
	return start_x;
}

int Blocks::get_y_start()
{
	return start_y;
}

void Blocks::toggle_rotation()
{
	if (b.rotation == 4)
		b.rotation = 1;
	else
		b.rotation++;

	int hold_x = b.width_height.x;
	b.width_height.x = b.width_height.y;
	b.width_height.y = hold_x;


	if (b.type == L)
	{
		if (b.rotation == 1)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 4)
		{
			b.block_start.x = 1;
			b.block_start.y = 0;
		}
	}
	else if (b.type == L_mirrored)
	{
		if (b.rotation == 1)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 4)
		{
			b.block_start.x = 1;
			b.block_start.y = 0;
		}
	}
	else if (b.type == square)
	{
		
		b.block_start.x = 0;
		b.block_start.y = 1;
		
	}
	else if (b.type == S)
	{
		if (b.rotation == 1 || b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2 || b.rotation == 4)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
	}
	else if (b.type == S_mirrored)
	{
		if (b.rotation == 1 || b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2 || b.rotation == 4)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
	}
	else if (b.type == T)
	{
		if (b.rotation == 1)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 0;
		}
		else if (b.rotation == 4)
		{
			b.block_start.x = 1;
			b.block_start.y = 0;
		}
	}
	else if (b.type == line)
	{
		if (b.rotation == 1 || b.rotation == 3)
		{
			b.block_start.x = 0;
			b.block_start.y = 1;
		}
		else if (b.rotation == 2 || b.rotation == 4)
		{
			b.block_start.x = 1;
			b.block_start.y = 0;
		}
	}
	return;
}

void Blocks::subtract_y()
{
	start_y--;
	return;
}

void Blocks::add_y()
{
	start_y++;
	return;
}

void Blocks::move_left()
{
	start_x--;
	return;
}

void Blocks::move_right()
{
	start_x++;
	return;
}

int Blocks::get_block_height()
{
	return b.width_height.y;
}

int Blocks::get_block_width()
{
	return b.width_height.x;
}

int Blocks::get_block_start_x()
{
	return b.block_start.x;
}

int Blocks::get_block_start_y()
{
	return b.block_start.y;
}