#pragma once
#include "common.h"

enum block_type
{
	L,
	L_mirrored,
	square,
	S,
	S_mirrored,
	T,
	line,
	TOTAL_NUM_TYPE
};

struct block
{
	block_type type;
	int rotation;
	SDL_Point width_height;
	SDL_Point block_start;
	int red, green, blue;
};

class Blocks
{
public:
	Blocks();
	~Blocks();
	int get_block_type();
	void print_block(std::vector<std::vector<int>> &grid);
	int get_x_start();
	int get_y_start();
	int get_block_height();
	int get_block_width();
	int get_block_start_x();
	int get_block_start_y();
	void toggle_rotation();
	void subtract_y();
	void add_y();
	void move_left();
	void move_right();
	void randomize_block();
	void randomize_color();
	int get_red();
	int get_green();
	int get_blue();
	bool is_block(int x, int y);
	
private:
	block b;
	int start_x;
	int start_y;
};
