#include "common.h"
#include "blocks.h"
#include "game.h"
#include "time.h"

SDL_Window* game_window = NULL;
SDL_Renderer* game_renderer = NULL;
TTF_Font* game_font = NULL;

// start up and quit functions
bool initialize();
bool load_media();
void close();

bool initialize()
{
	bool success = true;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize. SDL ERROR: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
			printf("Warning: Linear texture filtering not enabled!");
	}
	game_window = SDL_CreateWindow("Tetris", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	if (game_window == NULL)
	{
		printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		game_renderer = SDL_CreateRenderer(game_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
		if (game_renderer == NULL)
		{
			printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			SDL_SetRenderDrawColor(game_renderer, 0, 0, 0, 0);
			int imgFlags = IMG_INIT_PNG;
			if (!(IMG_Init(imgFlags) & imgFlags))
			{
				printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
				success = false;
			}
			if (TTF_Init() == -1)
			{
				printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
				success = false;
			}
		}
	}
	return success;
}

bool load_media()
{
	bool success = true;

	
	return success;
}

void close()
{
	TTF_CloseFont(game_font);
	game_font = NULL;

	SDL_DestroyRenderer(game_renderer);
	game_renderer = NULL;

	SDL_DestroyWindow(game_window);
	game_window = NULL;

	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

int main(int argc, char* args[])
{
	srand(time(NULL));

	if (!initialize())
	{
		printf("Failed to initialize.\n");
	}
	else
	{
		printf("initialize complete!\n");

		if (!load_media())
		{
			printf("Failed to load media.\n");
		}
		else
		{
			printf("load media complete!\n");
			bool quit = false;
			SDL_Event game_event;

			Game tetris_game;

			while (!quit)
			{
				// game event loop:
				while (SDL_PollEvent(&game_event) != 0)
				{
					if (game_event.type == SDL_QUIT)
						quit = true;

					tetris_game.handle_event(&game_event);
				}
				SDL_SetRenderDrawColor(game_renderer, 0, 0, 0, 0);
				SDL_RenderClear(game_renderer);

				tetris_game.run_game();

				SDL_RenderPresent(game_renderer);
			}
		}
	}
	close();
	return 0;
}