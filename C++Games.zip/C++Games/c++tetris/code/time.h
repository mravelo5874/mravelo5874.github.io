#pragma once
#include "common.h"

class Time
{
public:
	Time();
	void start();
	void stop();
	void pause();
	void unpause();
	void reset();

	Uint32 get_ticks();

	bool is_started();
	bool is_paused();

private:
	Uint32 start_ticks;
	Uint32 paused_ticks;
	bool paused;
	bool started;
};
