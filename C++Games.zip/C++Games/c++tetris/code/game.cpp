#include "game.h"

Game::Game()
{
	current_block.randomize_block();
	next_block.randomize_block();
	next_block.randomize_color();
	std::vector<std::vector<int>> grid(MAX, std::vector<int>(MAX, 0));
	movement_grid = grid;
	stacking_grid = grid;
	color_grid = std::vector<std::vector<RGB_color>> (MAX, std::vector<RGB_color>(MAX));
	game_timer.start();
	game_timer.pause();
}

Game::~Game()
{
	
}

void Game::run_game()
{
	game_timer.unpause();

	if (game_timer.get_ticks() >= 800)
	{
		if (current_block.get_y_start() + current_block.get_block_height() + current_block.get_block_start_y() - 1 < GAME_ROWS)
		{
			current_block.add_y();
			current_block.print_block(movement_grid);

			if (colide_with_block())
			{
				current_block.subtract_y();
				current_block.print_block(movement_grid);
				make_blocks_permanent();
			}
		}
		else
		{
			make_blocks_permanent();
		}
		game_timer.reset();
	}

		check_for_line(0);
		current_block.print_block(movement_grid);
		print();
}

void Game::move_everything_down(int y)
{
	for (y; y > 0; y--)
	{
		for (int x = 0; x < MAX; x++)
		{
			stacking_grid[x][y] = stacking_grid[x][y - 1];
			stacking_grid[x][y - 1] = 0;

			color_grid[x][y].red = color_grid[x][y - 1].red;
			color_grid[x][y].green = color_grid[x][y - 1].green;
			color_grid[x][y].blue = color_grid[x][y - 1].blue;
		}
	}
}

void Game::check_for_line(int y)
{
	for (y; y < MAX; y++)
	{
		if (stacking_grid[1][y] == 1)
		{
			int x = 1;
			int count = 0;
			while (x != GAME_COLUMNS + 1)
			{
				if (stacking_grid[x][y] == 1)
					count++;
				x++;
			}
			if (count == GAME_COLUMNS)
			{
				printf("line detected!\n");
				delete_line(y);
				move_everything_down(y);
				check_for_line(y + 1);
				return;
			}
		}
	}
	return;
}

void Game::delete_line(int y)
{
	for (int x = 0; x < MAX; x++)
	{
		stacking_grid[x][y] = 0;
	}
	return;
}

bool Game::check_game_over()
{
	for (int x = 0; x < MAX; x++)
	{
		if (stacking_grid[x][1] == 1)
		{
			return true;
		}
	}
	return false;
}

void Game::make_blocks_permanent()
{
	for (int y = 0; y < MAX; y++)
	{
		for (int x = 0; x < MAX; x++)
		{
			if (movement_grid[x][y] == 1)
			{
				stacking_grid[x][y] = movement_grid[x][y];
				color_grid[x][y].red = current_block.get_red();
				color_grid[x][y].green = current_block.get_green();
				color_grid[x][y].blue = current_block.get_blue();
			}
		}
	}

	current_block = next_block;
	next_block.randomize_block();
	next_block.randomize_color();
}

void Game::print()
{

	int start_X = (SCREEN_WIDTH - (GAME_COLUMNS * BLOCK_SIZE)) / 2;
	int start_Y = (SCREEN_HEIGHT - (GAME_ROWS * BLOCK_SIZE)) / 2;
	int end_X = GAME_COLUMNS * BLOCK_SIZE;
	int end_Y = GAME_ROWS * BLOCK_SIZE;

	SDL_Rect next_backscreen = { ((end_X - start_X) / 2) + start_X - 5, start_Y - (BLOCK_SIZE * 4) - 5, BLOCK_SIZE * 5 + 10, BLOCK_SIZE * 4 + 10};
	SDL_SetRenderDrawColor(game_renderer, 100, 100, 100, 255);
	SDL_RenderFillRect(game_renderer, &next_backscreen);

	SDL_Rect next_frontscreen = { ((end_X - start_X) / 2) + start_X, start_Y - (BLOCK_SIZE * 4), BLOCK_SIZE * 5, BLOCK_SIZE * 4 };
	SDL_SetRenderDrawColor(game_renderer, 50, 50, 50, 50);
	SDL_RenderFillRect(game_renderer, &next_frontscreen);

	for (int y = 0; y < 4; y++)
	{
		for (int x = 0; x < 4; x++)
		{
			if (next_block.is_block(x, y))
			{
				SDL_Rect block = { ((end_X - start_X) / 2) + start_X + (BLOCK_SIZE * x) + ((next_block.get_block_width() / 2) * BLOCK_SIZE), start_Y - (BLOCK_SIZE * 4) + (BLOCK_SIZE * y), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, next_block.get_red(), next_block.get_green(), next_block.get_blue(), 255);
				SDL_RenderFillRect(game_renderer, &block);

				SDL_Rect outline = { ((end_X - start_X) / 2) + start_X + (BLOCK_SIZE * x) + ((next_block.get_block_width() / 2) * BLOCK_SIZE), start_Y - (BLOCK_SIZE * 4) + (BLOCK_SIZE * y), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, 50, 50, 50, 255);
				SDL_RenderDrawRect(game_renderer, &outline);
			}
		}
	}

	SDL_Rect backscreen = { start_X - 5, start_Y - 5, end_X + 10, end_Y + 10 };
	SDL_SetRenderDrawColor(game_renderer, 100, 100, 100, 255);
	SDL_RenderFillRect(game_renderer, &backscreen);

	SDL_Rect frontscreen = { start_X - 1, start_Y - 1, end_X + 2, end_Y + 2 };
	SDL_SetRenderDrawColor(game_renderer, 50, 50, 50, 255);
	SDL_RenderFillRect(game_renderer, &frontscreen);

	for (int y = 1; y < GAME_ROWS + 1; y++)
	{
		for (int x = 1; x < GAME_COLUMNS + 1; x++)
		{
			if (movement_grid[x][y] == 0)
			{
				SDL_Rect block = { start_X + ((x - 1) * BLOCK_SIZE), start_Y + ((y - 1) * BLOCK_SIZE), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, 40, 40, 40, 255);
				SDL_RenderDrawRect(game_renderer, &block);
			}
			else if (movement_grid[x][y] == 1 )
			{
				SDL_Rect block = { start_X + ((x - 1) * BLOCK_SIZE), start_Y + ((y - 1) * BLOCK_SIZE), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, current_block.get_red(), current_block.get_green(), current_block.get_blue(), 255);
				SDL_RenderFillRect(game_renderer, &block);
				SDL_Rect outline = { start_X + ((x - 1) * BLOCK_SIZE), start_Y + ((y - 1) * BLOCK_SIZE), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, 40, 40, 40, 255);
				SDL_RenderDrawRect(game_renderer, &outline);
			}
			if (stacking_grid[x][y] == 1)
			{
				SDL_Rect block = { start_X + ((x - 1) * BLOCK_SIZE), start_Y + ((y - 1) * BLOCK_SIZE), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, color_grid[x][y].red, color_grid[x][y].green, color_grid[x][y].blue, 255);
				SDL_RenderFillRect(game_renderer, &block);
				SDL_Rect outline = { start_X + ((x - 1) * BLOCK_SIZE), start_Y + ((y - 1) * BLOCK_SIZE), BLOCK_SIZE, BLOCK_SIZE };
				SDL_SetRenderDrawColor(game_renderer, 40, 40, 40, 255);
				SDL_RenderDrawRect(game_renderer, &outline);
			}
		}
	}
}

bool Game::colide_with_block()
{
	for (int y = 0; y < MAX; y++)
	{
		for (int x = 0; x < MAX; x++)
		{
			if (movement_grid[x][y] == 1)
			{
				if (stacking_grid[x][y] == 1)
				{
					printf("collition detected!\n");
					return true;
				}
			}
		}
	}
	return false;
}

void Game::handle_event(SDL_Event* g_event)
{
	if (g_event->type == SDL_KEYDOWN)
	{
		switch (g_event->key.keysym.sym)
		{
		case SDLK_a:
		case SDLK_LEFT:
			if (current_block.get_x_start() + current_block.get_block_start_x() > 1)
			{
				current_block.move_left();
				current_block.print_block(movement_grid);

				if (colide_with_block())
				{
					current_block.move_right();
					current_block.print_block(movement_grid);
				}
			}
			break;
		case SDLK_d:
		case SDLK_RIGHT:
			if (current_block.get_x_start() + current_block.get_block_width() + current_block.get_block_start_x() - 1 < GAME_COLUMNS)
			{
				current_block.move_right();
				current_block.print_block(movement_grid);

				if (colide_with_block())
				{
					current_block.move_left();
					current_block.print_block(movement_grid);
				}
			}
			break;
		case SDLK_s:
		case SDLK_DOWN:
			if (current_block.get_y_start() + current_block.get_block_height() + current_block.get_block_start_y() - 1 < GAME_ROWS)
			{
				current_block.add_y();
				current_block.print_block(movement_grid);

				if  (colide_with_block())
				{
					current_block.subtract_y();
					current_block.print_block(movement_grid);
					make_blocks_permanent();
				}
			}
			else
			{
				make_blocks_permanent();
			}
			break;
		case SDLK_w:
		case SDLK_UP:
		{
			current_block.toggle_rotation();
			while (current_block.get_x_start() + current_block.get_block_start_x() <= 0)
			{
				current_block.move_right();
			}
			while (current_block.get_x_start() + current_block.get_block_width() - 1 > GAME_COLUMNS)
			{
				current_block.move_left();
			}
		}
		}
	}
}